﻿Option Strict On
Public Class frmSemesterGrades
    Dim userInput As String         'string to store user input before validation
    Dim validInput As Double        'string to store user input post validation
    Dim errorMessage As String      'string to store error messages
    Dim letter As String            'string to store grade letter, to be outputted later
    Dim arrayGrades(5) As Double    'array to hold grades, to sum and average them
    Dim total As Double             'variable to store total sum of grades array
    Dim average As Double           'variable to store array average


    Public Function validation(ByVal userInput As String) As Boolean                    'validation function, takes user's input and will output a true or false, determining if it is valid or not
        If (Double.TryParse(userInput, validInput)) = False Then                        'checks if user input is a numeric value
            errorMessage = "Please ensure your input is a number!"                      'if it isn't, it sets the appropriate error message and
            validation = False                                                          'sets valid state to false
        ElseIf ((validInput >= 0) AndAlso (validInput <= 100)) = False Then             'if the value is numeric it will then check if it is within the desired range
            errorMessage = "Please ensure your input is between 0 and 100 inclusive!"   'if it isn't, it sets the appropriate error message and
            validation = False                                                          'sets valid state to false
        Else validation = True                                                          'otherwise, it is a valid entry
        End If
        Return validation
    End Function

    Public Function gradeAsLetter(ByVal validInput As Double) As String                 'this function takes the validated input and converts the numeric grade into a representative letter

        Select Case validInput                                                          'using the validated input
            Case 90 To 100                                                              'if the number is from 90 to 100
                letter = "A+"                                                           'this is the letter equivalent
            Case 85 To 89                                                               'if the number is from 85 to 89
                letter = "A"                                                            'this is the letter equivalent
            Case 80 To 84                                                               'if the number is from 80 to 84
                letter = "A-"                                                           'this is the letter equivalent
            Case 77 To 79                                                               'if the number is from 77 to 79
                letter = "B+"                                                           'this is the letter equivalent
            Case 73 To 76                                                               'if the number is from 73 to 76
                letter = "B"                                                            'this is the letter equivalent
            Case 70 To 72                                                               'if the number is from 70 to 72
                letter = "B-"                                                           'this is the letter equivalent
            Case 67 To 69                                                               'if the number is from 67 to 69
                letter = "C+"                                                           'this is the letter equivalent
            Case 63 To 66                                                               'if the number is from 63 to 66
                letter = "C"                                                            'this is the letter equivalent
            Case 60 To 62                                                               'if the number is from 60 to 62
                letter = "C-"                                                           'this is the letter equivalent
            Case 57 To 59                                                               'if the number is from 57 to 69
                letter = "D+"                                                           'this is the letter equivalent
            Case 53 To 56                                                               'if the number is from 53 to 56
                letter = "D"                                                            'this is the letter equivalent
            Case 50 To 52                                                               'if the number is from 50 to 52
                letter = "D-"                                                           'this is the letter equivalent
            Case 0 To 49                                                                'if the number is from 0 to 49
                letter = "F"                                                            'this is the letter equivalent
        End Select
        Return letter
    End Function

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblCourse1.Click

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtInput1.Clear()                       'clear input
        txtInput2.Clear()                       'clear input
        txtInput3.Clear()                       'clear input
        txtInput4.Clear()                       'clear input
        txtInput5.Clear()                       'clear input
        txtInput6.Clear()                       'clear input
        btnCalculate.Enabled = True             'enable calculate button
        txtInput1.Enabled = True                'enable input
        txtInput2.Enabled = True                'enable input
        txtInput3.Enabled = True                'enable input
        txtInput4.Enabled = True                'enable input
        txtInput5.Enabled = True                'enable input
        txtInput6.Enabled = True                'enable input
        lblError.Text = ""                      'clear output
        lblGrade1.Text = ""                     'clear output
        lblGrade2.Text = ""                     'clear output
        lblGrade3.Text = ""                     'clear output
        lblGrade4.Text = ""                     'clear output
        lblGrade5.Text = ""                     'clear output
        lblGrade6.Text = ""                     'clear output
        errorMessage = ""                       'clear output
        validInput = 0                          'reset variable
        userInput = ""                          'reset variable
        lblOutput1.Text = ""                    'clear output
        lblOutput2.Text = ""                    'clear output
        average = 0                             'reset variable
        total = 0                               'reset variable
        Array.Clear(arrayGrades, 0, 5)          'reset array
        txtInput1.Focus()                       'set focus onto first textbox
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()                      'exit application

    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        If Not String.IsNullOrEmpty(txtInput1.Text) AndAlso Not String.IsNullOrEmpty(txtInput2.Text) _
        AndAlso Not String.IsNullOrEmpty(txtInput3.Text) _
        AndAlso Not String.IsNullOrEmpty(txtInput4.Text) _
        AndAlso Not String.IsNullOrEmpty(txtInput5.Text) _
        AndAlso Not String.IsNullOrEmpty(txtInput6.Text) Then       'this if statement prevents empty textboxes from crashing the program when the calculate button is pressed
            arrayGrades(0) = Convert.ToDouble(txtInput1.Text)       'grab first array element
            arrayGrades(1) = Convert.ToDouble(txtInput2.Text)       'grab second array element
            arrayGrades(2) = Convert.ToDouble(txtInput3.Text)       'grab third array element
            arrayGrades(3) = Convert.ToDouble(txtInput4.Text)       'grab fourth array element
            arrayGrades(4) = Convert.ToDouble(txtInput5.Text)       'grab fifth array element
            arrayGrades(5) = Convert.ToDouble(txtInput6.Text)       'grab sixth array element
            For arrayvalue As Integer = 0 To 5                      'cycle through array elements

                total += arrayGrades(arrayvalue)                    'add each element of array together
            Next
            average = (total / arrayGrades.Length)                  'calculate average
            Dim averageString = average.ToString("0.00")            'display average with 2 decimal places
            lblOutput1.Text = averageString                         'output average
            lblOutput2.Text = (gradeAsLetter(average))              'output average as letter
            btnCalculate.Enabled() = False                          'disable calculate button
            txtInput1.Enabled() = False                             'disable entry
            txtInput2.Enabled() = False                             'disable entry
            txtInput3.Enabled() = False                             'disable entry
            txtInput4.Enabled() = False                             'disable entry
            txtInput5.Enabled() = False                             'disable entry
            txtInput6.Enabled() = False                             'disable entry
        Else
            errorMessage = "Final calculations cannot occur before all data is entered. Please press tab after each grade, and press enter at the end." 'set error message
            lblError.Text = errorMessage                            'output error message

        End If
    End Sub

    Private Sub txtInput1_Leave(sender As Object, e As EventArgs) Handles txtInput1.Leave   'event for leaving text input box
        If btnReset.Focused = False Then                                                    'if reset is not focused (just pressed)
            If validation(txtInput1.Text) = True Then                                       'and if validation is successful
                lblGrade1.Text = gradeAsLetter((Convert.ToDouble(txtInput1.Text)))          'output grade letter
                lblError.Text = ""                                                          'clear error

            Else lblError.Text = errorMessage                                               'otherwise, display error
                txtInput1.Focus()                                                           'set focus back onto input
                txtInput1.Clear()                                                           'clear incorrect input
            End If
        End If

    End Sub

    Private Sub txtInput2_Leave(sender As Object, e As EventArgs) Handles txtInput2.Leave   'event for leaving text input box
        If btnReset.Focused = False Then                                                    'if reset is not focused (just pressed)
            If validation(txtInput2.Text) = True Then                                       'and if validation is successful
                lblGrade2.Text = gradeAsLetter(Convert.ToDouble(txtInput2.Text))            'output grade letter
                lblError.Text = ""                                                          'clear error

            Else lblError.Text = errorMessage                                               'otherwise, display error
                txtInput2.Focus()                                                           'set focus back onto input
                txtInput2.Clear()                                                           'clear incorrect input
            End If
        End If

    End Sub

    Private Sub txtInput3_Leave(sender As Object, e As EventArgs) Handles txtInput3.Leave   'event for leaving text input box
        If btnReset.Focused = False Then                                                    'if reset is not focused (just pressed)
            If validation(txtInput3.Text) = True Then                                       'and if validation is successful
                lblGrade3.Text = gradeAsLetter(Convert.ToDouble(txtInput3.Text))            'output grade letter
                lblError.Text = ""                                                          'clear error

            Else lblError.Text = errorMessage                                               'otherwise, display error
                txtInput3.Focus()                                                           'set focus back onto input
                txtInput3.Clear()                                                           'clear incorrect input
            End If
        End If
    End Sub

    Private Sub txtInput4_Leave(sender As Object, e As EventArgs) Handles txtInput4.Leave   'event for leaving text input box
        If btnReset.Focused = False Then                                                    'if reset is not focused (just pressed)
            If validation(txtInput4.Text) = True Then                                       'and if validation is successful
                lblGrade4.Text = gradeAsLetter(Convert.ToDouble(txtInput4.Text))            'output grade letter
                lblError.Text = ""                                                          'clear error

            Else lblError.Text = errorMessage                                               'otherwise, display error
                txtInput4.Focus()                                                           'set focus back onto input
                txtInput4.Clear()                                                           'clear incorrect input
            End If
        End If
    End Sub

    Private Sub txtInput5_Leave(sender As Object, e As EventArgs) Handles txtInput5.Leave   'event for leaving text input box
        If btnReset.Focused = False Then                                                    'if reset is not focused (just pressed)
            If validation(txtInput5.Text) = True Then                                       'and if validation is successful
                lblGrade5.Text = gradeAsLetter(Convert.ToDouble(txtInput5.Text))            'output grade letter
                lblError.Text = ""                                                          'clear error

            Else lblError.Text = errorMessage                                               'otherwise, display error
                txtInput5.Focus()                                                           'set focus back onto input
                txtInput5.Clear()                                                           'clear incorrect input
            End If
        End If
    End Sub

    Private Sub txtInput6_Leave(sender As Object, e As EventArgs) Handles txtInput6.Leave   'event for leaving text input box
        If btnReset.Focused = False Then                                                    'if reset is not focused (just pressed)
            If validation(txtInput6.Text) = True Then                                       'and if validation is successful
                lblGrade6.Text = gradeAsLetter(Convert.ToDouble(txtInput6.Text))            'output grade letter
                lblError.Text = ""                                                          'clear error

            Else lblError.Text = errorMessage                                               'otherwise, display error
                txtInput6.Focus()                                                           'set focus back onto input
                txtInput6.Clear()                                                           'clear incorrect input
            End If
        End If
    End Sub
End Class
