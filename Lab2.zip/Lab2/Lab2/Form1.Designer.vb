﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSemesterGrades
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblCourse1 = New System.Windows.Forms.Label()
        Me.lblCourse2 = New System.Windows.Forms.Label()
        Me.lblCourse3 = New System.Windows.Forms.Label()
        Me.lblCourse4 = New System.Windows.Forms.Label()
        Me.lblCourse5 = New System.Windows.Forms.Label()
        Me.lblCourse6 = New System.Windows.Forms.Label()
        Me.lblSemester = New System.Windows.Forms.Label()
        Me.txtInput1 = New System.Windows.Forms.TextBox()
        Me.txtInput3 = New System.Windows.Forms.TextBox()
        Me.txtInput2 = New System.Windows.Forms.TextBox()
        Me.txtInput6 = New System.Windows.Forms.TextBox()
        Me.txtInput5 = New System.Windows.Forms.TextBox()
        Me.txtInput4 = New System.Windows.Forms.TextBox()
        Me.lblOutput2 = New System.Windows.Forms.Label()
        Me.lblGrade6 = New System.Windows.Forms.Label()
        Me.lblGrade5 = New System.Windows.Forms.Label()
        Me.lblGrade4 = New System.Windows.Forms.Label()
        Me.lblGrade3 = New System.Windows.Forms.Label()
        Me.lblGrade2 = New System.Windows.Forms.Label()
        Me.lblGrade1 = New System.Windows.Forms.Label()
        Me.lblOutput1 = New System.Windows.Forms.Label()
        Me.lblError = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SemesterToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'lblCourse1
        '
        Me.lblCourse1.Location = New System.Drawing.Point(44, 26)
        Me.lblCourse1.Name = "lblCourse1"
        Me.lblCourse1.Size = New System.Drawing.Size(100, 23)
        Me.lblCourse1.TabIndex = 0
        Me.lblCourse1.Text = "Course &1:"
        Me.lblCourse1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCourse2
        '
        Me.lblCourse2.Location = New System.Drawing.Point(44, 75)
        Me.lblCourse2.Name = "lblCourse2"
        Me.lblCourse2.Size = New System.Drawing.Size(100, 23)
        Me.lblCourse2.TabIndex = 3
        Me.lblCourse2.Text = "Course &2:"
        Me.lblCourse2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCourse3
        '
        Me.lblCourse3.Location = New System.Drawing.Point(44, 124)
        Me.lblCourse3.Name = "lblCourse3"
        Me.lblCourse3.Size = New System.Drawing.Size(100, 23)
        Me.lblCourse3.TabIndex = 6
        Me.lblCourse3.Text = "Course &3:"
        Me.lblCourse3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCourse4
        '
        Me.lblCourse4.Location = New System.Drawing.Point(44, 171)
        Me.lblCourse4.Name = "lblCourse4"
        Me.lblCourse4.Size = New System.Drawing.Size(100, 23)
        Me.lblCourse4.TabIndex = 9
        Me.lblCourse4.Text = "Course &4:"
        Me.lblCourse4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCourse5
        '
        Me.lblCourse5.Location = New System.Drawing.Point(44, 222)
        Me.lblCourse5.Name = "lblCourse5"
        Me.lblCourse5.Size = New System.Drawing.Size(100, 23)
        Me.lblCourse5.TabIndex = 12
        Me.lblCourse5.Text = "Course &5:"
        Me.lblCourse5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCourse6
        '
        Me.lblCourse6.Location = New System.Drawing.Point(44, 271)
        Me.lblCourse6.Name = "lblCourse6"
        Me.lblCourse6.Size = New System.Drawing.Size(100, 23)
        Me.lblCourse6.TabIndex = 15
        Me.lblCourse6.Text = "Course &6:"
        Me.lblCourse6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblSemester
        '
        Me.lblSemester.Location = New System.Drawing.Point(44, 320)
        Me.lblSemester.Name = "lblSemester"
        Me.lblSemester.Size = New System.Drawing.Size(100, 23)
        Me.lblSemester.TabIndex = 18
        Me.lblSemester.Text = "&Semester:"
        Me.lblSemester.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtInput1
        '
        Me.txtInput1.Location = New System.Drawing.Point(150, 27)
        Me.txtInput1.Name = "txtInput1"
        Me.txtInput1.Size = New System.Drawing.Size(100, 22)
        Me.txtInput1.TabIndex = 1
        Me.txtInput1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.SemesterToolTip.SetToolTip(Me.txtInput1, "Enter the grade for your first course here")
        '
        'txtInput3
        '
        Me.txtInput3.Location = New System.Drawing.Point(150, 123)
        Me.txtInput3.Name = "txtInput3"
        Me.txtInput3.Size = New System.Drawing.Size(100, 22)
        Me.txtInput3.TabIndex = 7
        Me.txtInput3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.SemesterToolTip.SetToolTip(Me.txtInput3, "Enter the grade for your third course here")
        '
        'txtInput2
        '
        Me.txtInput2.Location = New System.Drawing.Point(150, 75)
        Me.txtInput2.Name = "txtInput2"
        Me.txtInput2.Size = New System.Drawing.Size(100, 22)
        Me.txtInput2.TabIndex = 4
        Me.txtInput2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.SemesterToolTip.SetToolTip(Me.txtInput2, "Enter the grade for your second course here")
        '
        'txtInput6
        '
        Me.txtInput6.Location = New System.Drawing.Point(150, 267)
        Me.txtInput6.Name = "txtInput6"
        Me.txtInput6.Size = New System.Drawing.Size(100, 22)
        Me.txtInput6.TabIndex = 16
        Me.txtInput6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.SemesterToolTip.SetToolTip(Me.txtInput6, "Enter the grade for your sixth course here")
        '
        'txtInput5
        '
        Me.txtInput5.Location = New System.Drawing.Point(150, 219)
        Me.txtInput5.Name = "txtInput5"
        Me.txtInput5.Size = New System.Drawing.Size(100, 22)
        Me.txtInput5.TabIndex = 13
        Me.txtInput5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.SemesterToolTip.SetToolTip(Me.txtInput5, "Enter the grade for your fifth course here")
        '
        'txtInput4
        '
        Me.txtInput4.Location = New System.Drawing.Point(150, 171)
        Me.txtInput4.Name = "txtInput4"
        Me.txtInput4.Size = New System.Drawing.Size(100, 22)
        Me.txtInput4.TabIndex = 10
        Me.txtInput4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.SemesterToolTip.SetToolTip(Me.txtInput4, "Enter the grade for your fourth course here")
        '
        'lblOutput2
        '
        Me.lblOutput2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblOutput2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutput2.Location = New System.Drawing.Point(289, 316)
        Me.lblOutput2.Name = "lblOutput2"
        Me.lblOutput2.Size = New System.Drawing.Size(100, 23)
        Me.lblOutput2.TabIndex = 20
        Me.lblOutput2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.SemesterToolTip.SetToolTip(Me.lblOutput2, "Your semester grade will appear here")
        '
        'lblGrade6
        '
        Me.lblGrade6.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblGrade6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGrade6.Location = New System.Drawing.Point(289, 266)
        Me.lblGrade6.Name = "lblGrade6"
        Me.lblGrade6.Size = New System.Drawing.Size(100, 23)
        Me.lblGrade6.TabIndex = 17
        Me.lblGrade6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.SemesterToolTip.SetToolTip(Me.lblGrade6, "Your letter grade will appear here")
        '
        'lblGrade5
        '
        Me.lblGrade5.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblGrade5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGrade5.Location = New System.Drawing.Point(289, 218)
        Me.lblGrade5.Name = "lblGrade5"
        Me.lblGrade5.Size = New System.Drawing.Size(100, 23)
        Me.lblGrade5.TabIndex = 14
        Me.lblGrade5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.SemesterToolTip.SetToolTip(Me.lblGrade5, "Your letter grade will appear here")
        '
        'lblGrade4
        '
        Me.lblGrade4.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblGrade4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGrade4.Location = New System.Drawing.Point(289, 169)
        Me.lblGrade4.Name = "lblGrade4"
        Me.lblGrade4.Size = New System.Drawing.Size(100, 23)
        Me.lblGrade4.TabIndex = 11
        Me.lblGrade4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.SemesterToolTip.SetToolTip(Me.lblGrade4, "Your letter grade will appear here")
        '
        'lblGrade3
        '
        Me.lblGrade3.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblGrade3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGrade3.Location = New System.Drawing.Point(289, 120)
        Me.lblGrade3.Name = "lblGrade3"
        Me.lblGrade3.Size = New System.Drawing.Size(100, 23)
        Me.lblGrade3.TabIndex = 8
        Me.lblGrade3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.SemesterToolTip.SetToolTip(Me.lblGrade3, "Your letter grade will appear here")
        '
        'lblGrade2
        '
        Me.lblGrade2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblGrade2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGrade2.Location = New System.Drawing.Point(289, 71)
        Me.lblGrade2.Name = "lblGrade2"
        Me.lblGrade2.Size = New System.Drawing.Size(100, 23)
        Me.lblGrade2.TabIndex = 5
        Me.lblGrade2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.SemesterToolTip.SetToolTip(Me.lblGrade2, "Your letter grade will appear here")
        '
        'lblGrade1
        '
        Me.lblGrade1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblGrade1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGrade1.Location = New System.Drawing.Point(289, 22)
        Me.lblGrade1.Name = "lblGrade1"
        Me.lblGrade1.Size = New System.Drawing.Size(100, 23)
        Me.lblGrade1.TabIndex = 2
        Me.lblGrade1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.SemesterToolTip.SetToolTip(Me.lblGrade1, "Your letter grade will appear here")
        '
        'lblOutput1
        '
        Me.lblOutput1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblOutput1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutput1.Location = New System.Drawing.Point(150, 316)
        Me.lblOutput1.Name = "lblOutput1"
        Me.lblOutput1.Size = New System.Drawing.Size(100, 23)
        Me.lblOutput1.TabIndex = 19
        Me.lblOutput1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.SemesterToolTip.SetToolTip(Me.lblOutput1, "Your semester average will appear here")
        '
        'lblError
        '
        Me.lblError.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblError.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblError.Location = New System.Drawing.Point(47, 375)
        Me.lblError.Name = "lblError"
        Me.lblError.Size = New System.Drawing.Size(342, 212)
        Me.lblError.TabIndex = 21
        Me.SemesterToolTip.SetToolTip(Me.lblError, "Error Output")
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(69, 603)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(92, 23)
        Me.btnCalculate.TabIndex = 22
        Me.btnCalculate.Text = "&Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(161, 603)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(92, 23)
        Me.btnReset.TabIndex = 23
        Me.btnReset.Text = "&Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(253, 603)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(92, 23)
        Me.btnExit.TabIndex = 24
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmSemesterGrades
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(420, 638)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lblError)
        Me.Controls.Add(Me.lblOutput1)
        Me.Controls.Add(Me.lblOutput2)
        Me.Controls.Add(Me.lblGrade6)
        Me.Controls.Add(Me.lblGrade5)
        Me.Controls.Add(Me.lblGrade4)
        Me.Controls.Add(Me.lblGrade3)
        Me.Controls.Add(Me.lblGrade2)
        Me.Controls.Add(Me.lblGrade1)
        Me.Controls.Add(Me.txtInput4)
        Me.Controls.Add(Me.txtInput5)
        Me.Controls.Add(Me.txtInput6)
        Me.Controls.Add(Me.txtInput2)
        Me.Controls.Add(Me.txtInput3)
        Me.Controls.Add(Me.txtInput1)
        Me.Controls.Add(Me.lblSemester)
        Me.Controls.Add(Me.lblCourse6)
        Me.Controls.Add(Me.lblCourse5)
        Me.Controls.Add(Me.lblCourse4)
        Me.Controls.Add(Me.lblCourse3)
        Me.Controls.Add(Me.lblCourse2)
        Me.Controls.Add(Me.lblCourse1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSemesterGrades"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Semester Grades"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblCourse1 As Label
    Friend WithEvents lblCourse2 As Label
    Friend WithEvents lblCourse3 As Label
    Friend WithEvents lblCourse4 As Label
    Friend WithEvents lblCourse5 As Label
    Friend WithEvents lblCourse6 As Label
    Friend WithEvents lblSemester As Label
    Friend WithEvents txtInput1 As TextBox
    Friend WithEvents txtInput3 As TextBox
    Friend WithEvents txtInput2 As TextBox
    Friend WithEvents txtInput6 As TextBox
    Friend WithEvents txtInput5 As TextBox
    Friend WithEvents txtInput4 As TextBox
    Friend WithEvents lblOutput2 As Label
    Friend WithEvents lblGrade6 As Label
    Friend WithEvents lblGrade5 As Label
    Friend WithEvents lblGrade4 As Label
    Friend WithEvents lblGrade3 As Label
    Friend WithEvents lblGrade2 As Label
    Friend WithEvents lblGrade1 As Label
    Friend WithEvents lblOutput1 As Label
    Friend WithEvents lblError As Label
    Friend WithEvents SemesterToolTip As ToolTip
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
End Class
