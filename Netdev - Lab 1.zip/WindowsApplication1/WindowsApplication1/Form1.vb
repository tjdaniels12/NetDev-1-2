﻿Public Class frmAverageUnitsShipped

    Dim arrayNumbers(6) As Double ' Array size
    Dim days As Integer = 1       ' variable for days, set to 1 to start
    Dim total As Double           ' variable for total, used for sum of array
    Dim average As Double         ' variable for average, used to calculate average of the array elements
    Dim userInput As Double       ' variable to hold user input, to be parsed





    Private Sub frmAverageUnitsShipped_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtUnits.Clear() ' clears txtUnits
        lblDays.Text = "Day: 1" ' change lbldays display back to default
        txtOutput.Clear() ' clear output textbox
        lblOutput.Text = "" ' clear output label
        btnEnter.Enabled = True ' enable btnEnter
        txtUnits.Enabled = True ' enable txtUnits
        txtUnits.Focus() ' shift focus to txtUnits for user to easily enter more information
        total = 0 'reset total in case of form reset



    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        If Integer.TryParse(txtUnits.Text, userInput) And userInput >= 0 And userInput <= 1000 Then ' data validation, allowing only whole numbers and preventing out of range numbers or strings

            arrayNumbers(days - 1) = txtUnits.Text ' store user entered units into array

            days += 1 ' increment days

            txtOutput.AppendText(txtUnits.Text & vbCrLf) ' display units on multiple lines

            txtUnits.Clear() ' clear user entry

            lblDays.Text = "&Day: " & days ' display newly incremented day

            If days = 8 Then 'when max days is reached and average calculation is displayed
                For arrayvalue As Integer = 0 To 6 ' cycle through array elements

                    total += arrayNumbers(arrayvalue) ' add each element of array together


                Next arrayvalue
                average = total / 7 ' calculate average of array elements
                Dim averageString = average.ToString("0.00") ' display average with 2 decimal places
                lblOutput.Text = "The average across 7 days is: " & averageString ' display calculated average
                btnEnter.Enabled = False ' disable enter button
                txtUnits.Enabled = False ' disable user entry
                lblDays.Text = "&Day: 7" ' keep day label set at 7
                days = 1 ' reset days in case of form reset


            End If

        Else
            MessageBox.Show("Error. Please enter a whole number from 0 to 1000.") ' error message

        End If

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit() ' exit form

    End Sub
End Class
